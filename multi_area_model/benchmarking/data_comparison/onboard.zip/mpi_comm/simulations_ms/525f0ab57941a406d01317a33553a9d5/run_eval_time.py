"""
This script is used to run a simulation

It initializes the network class and then runs the simulate method of
the simulation class instance.

"""

import json
import os
import sys
import numpy as np
from config import base_path, data_path
from multiarea_model import MultiAreaModel
from mpi4py import MPI
import shutil
from multiarea_model.default_params import nested_update, sim_params

import nestgpu as ngpu

ngpu.ConnectMpiInit()


comm = MPI.COMM_WORLD
rank = comm.Get_rank()

mpi_np = ngpu.HostNum()

d = {}
conn_params = {'g': -11.,
               'K_stable': os.path.join(base_path, 'K_stable.npy'),
               'replace_non_simulated_areas': 'hom_poisson_stat',
               'fac_nu_ext_TH': 1.2,
               'fac_nu_ext_5E': 1.125,
               'fac_nu_ext_6E': 1.41666667,
               'av_indegree_V1': 3950.,
	       'cc_weights_factor': 1.9,
	       'cc_weights_I_factor': 2.0}
input_params = {'rate_ext': 10.}

neuron_params = {'V0_mean': -150.,
                 'V0_sd': 50.}

network_params = {'N_scaling': 1.0,
                  'K_scaling': 1.0,
                  'connection_params': conn_params,
                  'input_params': input_params,
                  'neuron_params': neuron_params}

sim_params = {'t_sim': 10000.,
              'recording_dict': {'record_vm': False, 'areas_recorded':[]}}


if rank==0:
    sim_params['master_seed'] = 1012345
    M = MultiAreaModel(network_params, simulation=True,
                       sim_spec=sim_params)
    label = M.simulation.label
    shutil.copy2(os.path.join(base_path, 'run_eval_time.py'),
                 os.path.join(data_path, label))

    fn = os.path.join(data_path,
                      label,
                      '_'.join(('custom_params',
                                label)))
    with open(fn, 'r') as f:
        custom_params = json.load(f)
    nested_update(sim_params, custom_params['sim_params'])

    for i in range(mpi_np):
        shutil.copy(fn, '_'.join((fn, str(i))))
    d = {'label': label,
         'network_label': custom_params['network_label'],
         'base_path': base_path,
         'sim_dir': os.path.join(data_path, label)}

else:
    label = None

label = comm.bcast(label, root=0)

fn = os.path.join(data_path,
                  label,
                  '_'.join(('custom_params',
                            label,
                           str(rank))))
with open(fn, 'r') as f:
    custom_params = json.load(f)

os.remove(fn)

network_label = custom_params['network_label']

M = MultiAreaModel(network_label,
                   simulation=True,
                   analysis=False,
                   sim_spec=custom_params['sim_params'])

M.simulation.simulate()
