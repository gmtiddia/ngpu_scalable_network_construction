#!/bin/bash -x
#SBATCH --account=IscrB_ngpu-opt
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=8
#SBATCH --time=00:30:00
#SBATCH --partition=boost_usr_prod
#SBATCH --qos=boost_qos_dbg
####SBATCH --gres=gpu:4
#SBATCH --gpus-per-task=1
#SBATCH --exclusive
#SBATCH --output=/leonardo_scratch/large/userexternal/bgolosio/test_ngpu_hpcb_out.%j
#SBATCH --error=/leonardo_scratch/large/userexternal/bgolosio/test_ngpu_hpcb_err.%j
# *** start of job script ***
# Note: The current working directory at this point is
# the directory where sbatch was executed.

###export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}
if [ "$#" -lt 1 ]; then
    opt=2
else
    opt=$1
fi
if [ "$#" -lt 2 ]; then
    run=0
else
    run=$2
fi

out_dir=opt_${opt}_run_${run}
mkdir -p $out_dir

seed=12345${run}

nodes=128
proc_num=$(expr $nodes \* 4)

max_spike_per_host_fact=$(echo "scale=6; 1.0/$nodes" | bc -l)
if (( $(bc <<< "$max_spike_per_host_fact>0.01") )) ; then
    max_spike_per_host_fact=0.01
fi

srun python3 ../../hpc_benchmark.py --scale 10.0 --simtime 1000.0 --opt $opt --seed $seed --path $out_dir --max_spike_per_host_fact $max_spike_per_host_fact --fake_mpi_proc_num $proc_num --fake_mpi_proc_id -1
sacct -j ${SLURM_JOB_ID}.0   --format='JobID,MaxVMSize' > $out_dir/stat.dat
