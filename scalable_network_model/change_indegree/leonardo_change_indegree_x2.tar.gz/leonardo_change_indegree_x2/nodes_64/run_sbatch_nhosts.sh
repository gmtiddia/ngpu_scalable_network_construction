#!/bin/bash -x
#SBATCH --account=INF26_brainsta
#SBATCH --nodes=65
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=8
#SBATCH --time=00:30:00
#SBATCH --partition=boost_usr_prod
#SBATCH --qos=boost_qos_bprod
#SBATCH --gres=gpu:4
#SBATCH --gpus-per-task=1
#SBATCH --exclusive
#SBATCH --output=/leonardo_scratch/large/userexternal/bgolosio/test_ngpu_hpcb_out.%j
#SBATCH --error=/leonardo_scratch/large/userexternal/bgolosio/test_ngpu_hpcb_err.%j
# *** start of job script ***
# Note: The current working directory at this point is
# the directory where sbatch was executed.

###export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}
if [ "$#" -lt 1 ]; then
    opt=2
else
    opt=$1
fi
if [ "$#" -lt 2 ]; then
    run=0
else
    run=$2
fi

out_dir=opt_${opt}_run_${run}
mkdir -p $out_dir

if [ "$opt" -gt 2 ]; then
    record_spikes=0
else
    record_spikes=1
fi

seed=12345${run}

nodes=64
proc_num=$(expr $nodes \* 4)

srun python3 ../../hpc_benchmark_change_indegree.py --scale 2.0 --simtime 1000.0 --opt $opt --seed $seed --path $out_dir --record_spikes $record_spikes --nhosts $proc_num
sacct -j ${SLURM_JOB_ID}.0   --format='JobID,MaxVMSize' > $out_dir/stat.dat

