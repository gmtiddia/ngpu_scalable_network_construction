rm -f */alpha_*.dat
